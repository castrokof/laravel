<?php if($item["submenu"]==[]): ?>
<li class="nav-item has-treeview" >
    <a href="<?php echo e(url($item['url'])); ?>" class="nav-link">
      <i class="nav-icon <?php echo e($item["icono"]); ?>"></i>
      <p>
        <?php echo e($item["nombre"]); ?>

      </p>
    </a>
<?php else: ?>
    <li class="nav-item has-treeview">
        <a href="#" class="nav-link">
            <i class="nav-icon <?php echo e($item["icono"]); ?>"></i>
            <p>
             <?php echo e($item["nombre"]); ?>

            </p>
            <i class="right fas fa-angle-left"></i>
        </a>
        <ul class="nav nav-treeview">
            <?php $__currentLoopData = $item["submenu"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make("theme.$theme.menu-item",["item" => $submenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>   
    </li>    
<?php endif; ?><?php /**PATH C:\xampp\htdocs\manteliviano\resources\views/theme/lte/menu-item.blade.php ENDPATH**/ ?>