<?php $__env->startSection('titulo'); ?>
    Usuarios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset("assets/pages/scripts/admin/usuario/index.js")); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset("assets/pages/scripts/admin/usuario/crear.js")); ?>" type="text/javascript"></script>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-12">
        <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('includes.form-mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card card-info">
        <div class="card-header with-border">
          <h3 class="card-title">Usuarios</h3>
          <div class="card-tools pull-right">
            <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal-xl"><i class="fa fa-fw fa-plus-circle"></i> Nuevo Usuario</button>
            </button>
          </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0">
      <table id="tabla-data" class="table table-hover table-bordered text-nowrap">
        <thead>
        <tr>
              <th>Id</th>
              <th>Usuario</th>
              <th>Nombre</th>
              <th>Tipo de Usuario</th>
              <th>Email</th>
              <th>Empresa</th>
              <th>Password</th>
              <th>Estado</th>
              <th class="width80">Acciones</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data1->id); ?></td>
                <td><?php echo e($data1->usuario); ?></td>
                <td><?php echo e($data1->nombre); ?></td>
                <td><?php echo e($data1->tipodeusuario); ?></td>
                <td><?php echo e($data1->email); ?></td>
                <td><?php echo e($data1->empresa); ?></td>
                <td><?php echo e($data1->password); ?></td>
                <td><?php echo e($data1->estado); ?></td>
                <td>
                <a href="<?php echo e(url("admin/usuario/$data1->id/editar")); ?>" class="btn-accion-tabla tooltipsC" title="Editar este registro">
                  <i class="fa fa-fw fa-pencil-alt"></i>
                </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
</div>
</div>
</div>

    <div class="modal fade" tabindex="-1" id ="modal-xl" role="dialog" aria-labelledby="myLargeModalLabel">
        <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">   
        <div class="row">
            <div class="col-lg-12">    
               <div class="card card-warning">
                <div class="card-header">
                  <h3 class="card-title">Crear Usuarios</h3>
                  <div class="card-tools pull-right">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
              <form action="<?php echo e(route('guardar_usuario')); ?>" id="form-general" class="form-horizontal" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                                  <?php echo $__env->make('admin.usuario.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                              </div>
                              <!-- /.card-body -->
                              <div class="card-footer">
                                
                                  <div class="col-lg-3"></div>
                                  <div class="col-lg-6">
                                  <?php echo $__env->make('includes.boton-form-crear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                              </div>
                               </div>
                              <!-- /.card-footer -->
              </form>
                         
            
               
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>



<?php echo $__env->make("theme.$theme.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\manteliviano\resources\views/admin/usuario/index.blade.php ENDPATH**/ ?>