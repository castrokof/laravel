<div class="form-group row">
    <div class="col-lg-3">
        <label for="usuario" class="col-xs-4 control-label requerido">Usuario</label>
        <input type="text" name="usuario" id="usuario" class="form-control" value="<?php echo e(old('usuario', $data->usuario ?? '')); ?>" required >
    </div>
    <div class="col-lg-3">
    <label for="nombre" class="col-xs-4 control-label requerido">Nombre</label>
    <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e(old('nombre', $data->nombre ?? '')); ?>" required >
    </div>
    <div class="col-lg-3">
                    <label for="tipodeusuario" class="col-xs-4 control-label requerido">tipo de usuario</label>
                    <select name="tipodeusuario" id="tipodeusuario" class="form-control select2bs4" style="width: 100%;">
                        <option value="">---seleccione el estado---</option>
                        <option value="administrativo" <?php echo e(($data->tipodeusuario == 'administrativo') ? 'selected' : ''); ?>>administrativo</option>
                        <option value="movil" <?php echo e(($data->tipodeusuario == 'movil') ? 'selected' : ''); ?>>movil</option>
                        </select>
    </div>
    <div class="col-lg-3">
        <label for="email" class="col-xs-4 control-label requerido">E-mail</label>
        <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email', $data->email ?? '')); ?>" required >
    </div>
</div>
<div class="form-group row">
    <div class="col-lg-3">
        <label for="empresa" class="col-xs-4 control-label requerido">Empresa</label>
        <input type="text" name="empresa" id="empresa" class="form-control" value="<?php echo e(old('empresa', $data->empresa ?? '')); ?>" required >
    </div>
    <div class="col-lg-3">
    <label for="password" class="col-xs-4 control-label requerido">Password</label>
    <input type="password" name="password" id="password" class="form-control" value="<?php echo e(old('password', $data->password ?? '')); ?>" required >
    </div>
    <div class="col-lg-3">
        <label for="re_password" class="col-xs-4 control-label requerido">repita el password</label>
        <input type="password" name="re_password" id="re_password" class="form-control" value="<?php echo e(old('password', $data->password ?? '')); ?>" required >
    </div>
    <div class="col-lg-3">
        <label for="estado" class="col-xs-4 control-label requerido">Estado</label>
                    <select name="estado" id="estado" class="form-control select2bs4" style="width: 100%;">
                    <option value="">---seleccione el estado---</option>
                    <option value="activo" <?php echo e(($data->estado === "activo") ?  "selected" : ""); ?>>activo</option>
                    <option value="inactivo" <?php echo e(($data->estado === "inactivo") ?  "selected" : ""); ?>>inactivo</option>
                    </select>
        </div>
    <div class="col-lg-3">
        <label for="rol_id" class="col-xs-4 control-label requerido">Estado</label>
                        <select name="rol_id" id="rol_id" class="form-control select2bs4" style="width: 100%;">
                        <option value="">---seleccione el rol---</option>
                        <?php $__currentLoopData = $Rols1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('rol_id', $data->roles1[0]->id ?? "") == $id ? "selected" : ""); ?>><?php echo e($nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
    </div>   


   

</div>
<?php /**PATH C:\xampp\htdocs\manteliviano\resources\views/admin/usuario/form-editar.blade.php ENDPATH**/ ?>