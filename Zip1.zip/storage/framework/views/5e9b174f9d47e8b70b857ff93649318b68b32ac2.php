<?php if(session("mensaje")): ?>
<div class="alert alert-success alert-dismissible" data-auto-dismiss="5000">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h5><i class="icon fas fa-check"></i> Mensaje Sistema de Manteliviano</h5>
       <li><?php echo e(session("mensaje")); ?></li>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\manteliviano\resources\views/includes/form-mensaje.blade.php ENDPATH**/ ?>