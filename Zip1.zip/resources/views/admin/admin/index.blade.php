@extends("theme.$theme.layout")
@section('titulo')
  Administrador
@endsection


@section('contenido')
<div class="row">

    <div class="col-lg-12">

        <h4>Bienvenido<h4>

    </div>

</div>

@endsection  